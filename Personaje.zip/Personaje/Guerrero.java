package Personaje;
public class Guerrero extends Personaje {
    private int estructura;
    
    public Guerrero(String auxNom){
        this.nombre=auxNom;
        this.energia=100;
        this.estructura=90;
        this.clase="Tanque";
    }
    
}