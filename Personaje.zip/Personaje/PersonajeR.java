package Personaje;
import java.util.Random;
public class PersonajeR extends Personaje{
    protected int reflejo;
    private Random random;

    public boolean esquivar(){
        random=new Random();
        int rand = random.nextInt(180) + 1;
        return rand <= reflejo;
    }
}
