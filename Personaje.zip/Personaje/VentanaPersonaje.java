package Personaje;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
public class VentanaPersonaje extends JFrame {
    private Logica miLogica;
    private JPanel miPanel;
    private JButton btnRegistrar;
    private JButton btnListar;

	
	public static void main(String[] args) {
		VentanaPersonaje miVentana = new VentanaPersonaje();
		miVentana.setVisible(true);
	}

    public VentanaPersonaje() {
        super("Personaje");
		miLogica = new Logica();
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(100, 100, 500, 300);
		
		miPanel = new JPanel();
		miPanel.setBorder(new EmptyBorder(5,5,5,5));
		miPanel.setLayout(null);
		this.setContentPane(miPanel);

        btnRegistrar = new JButton();
		btnRegistrar.setBounds(200, 50, 100, 20);
		miPanel.add(btnRegistrar);
		btnRegistrar.setText("REGISTRAR");
		btnRegistrar.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				registrarPersonaje();
			}
		});


        btnListar = new JButton();
		btnListar.setBounds(200, 90, 100, 20);
		miPanel.add(btnListar);
		btnListar.setText("LISTAR");
		btnListar.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				listarPersonaje();
			}

            
		});
    }
    private void registrarPersonaje(){
        VentanaRegistrar miRegistro =new VentanaRegistrar(miLogica);
        miRegistro.setVisible(true);
    }
    
    private void listarPersonaje() {
        VentanaListar miListar =new VentanaListar(miLogica);
        miListar.setVisible(true);
    }
}