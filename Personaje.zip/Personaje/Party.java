package Personaje;
import java.util.ArrayList;

public class Party {
    private ArrayList<Personaje> personajes;

    public Party() {
        personajes = new ArrayList<Personaje>();
    }

    public boolean agregarPersonaje(Personaje p) {
        boolean agregar=false;
        try{
            personajes.add(p);
            agregar=true;
        }catch(Exception e){
            agregar = false;
        }
        return agregar;
    }

    public boolean quitarPersonaje(String auxNom) {
        boolean quitar=false;
        try{
            personajes.remove(buscarPersonaje(auxNom));
            quitar=true;
        }catch(Exception e){
            quitar = false;
        }
        return quitar;
    }

    public boolean reemplazarPersonaje(String viejo, Personaje nuevo) {
        boolean reemplazar=false;
        try{
            personajes.remove(buscarPersonaje(viejo));
            reemplazar=true;
        }catch(Exception e){
            reemplazar = false;
        }
        return reemplazar;
    }

    public boolean cambiarNombre(String viejo, String nuevo) {
        boolean cambiar=false;
        try{
            personajes.get(buscarPersonaje(viejo)).setNombre(nuevo);
            cambiar=true;
        }catch(Exception e){
            cambiar = false;
        }
        return cambiar;
    }

    public String[] listadoPersonajes() {
		String[] resultado;
		if (hayPersonaje()) {
			resultado = new String[personajes.size()];
			for (int i=0; i < personajes.size();i++) {
				resultado[i] = personajes.get(i).toString();
			}
		}else {
			resultado = null;
		}
		return resultado;
	}

    public boolean existePersonaje(String nombre) {
            boolean existe = false;
            int i=0;
		if (hayPersonaje()) {
			while(i < personajes.size() && !(i >= personajes.size())) {
                if(nombre.equals(personajes.get(i).getNombre())){
                    existe = true;
                }
				i++;
			}
		}
		return existe;
	}
    
    public int buscarPersonaje(String nombre) {
            int i = 0;
		if (hayPersonaje()) {
			while(i < personajes.size() && !nombre.equals(personajes.get(i).getNombre())) {
				i++;
			}
			if (i >= personajes.size()) {
				i = -1;
			}
		}else {
			i = -1;
		}
		return i;
	}

    public boolean hayPersonaje(){
        boolean haypersonaje=false;
        if(personajes.size()>0){
            haypersonaje=true;
        }
        return haypersonaje;
    }


    public boolean hayLugar(){
        boolean haylugar=false;
        if(personajes.size()<6){
            haylugar=true;
        }
        return haylugar;
    }

    public boolean espacioClase(String clase){
        int count=0;
        int i=0;
        if (hayPersonaje()) {
			while(i < personajes.size()) {
                if (!clase.equals(personajes.get(i).getClase())) {
                    count++;
                }
                i++;
			}
		}
		return count<2;
    }

    public boolean personajeAgotado(String auxNom){
        return personajes.get(buscarPersonaje(auxNom)).estaAgotado();
    }

    public boolean bajoEfecto(String auxNom){
        return personajes.get(buscarPersonaje(auxNom)).bajoEfecto();
    }
}

