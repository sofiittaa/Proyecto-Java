package Personaje;

public class Asesino extends PersonajeR {

    public Asesino(String auxNom){
        this.nombre=auxNom;
        this.energia=100;
        this.reflejo=90;
        this.clase="Asesino";
    }
}