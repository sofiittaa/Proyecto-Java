package Personaje;
public class Logica {
    private Party party;
    public Logica(){
        party=new Party();
    }

    public boolean agregarPersonaje1(String auxNom) {
        boolean agregar=false;
        if(party.hayLugar()){
            if(party.buscarPersonaje(auxNom)==-1){
                if(party.espacioClase("Tanque")){
                    Guerrero aux =new Guerrero(auxNom);
                    party.agregarPersonaje(aux);
                    agregar=true;
                }
            }
        }
        return agregar;
    }

    public boolean agregarPersonaje2(String auxNom) {
        boolean agregar=false;
        if(party.hayLugar()){
            if(party.buscarPersonaje(auxNom)==-1){
                if(party.espacioClase("Asesino")){
                    Asesino aux =new Asesino(auxNom);
                    party.agregarPersonaje(aux);
                    agregar=true;
                }
            }
        }
        return agregar;
    }

    public boolean agregarPersonaje3(String auxNom) {
        boolean agregar=false;
        if(party.hayLugar()){
            if(party.buscarPersonaje(auxNom)==-1){
                if(party.espacioClase("Mentalista")){
                    Mentalista aux =new Mentalista(auxNom);
                    party.agregarPersonaje(aux);
                    agregar=true;
                }
            }
        }
        return agregar;
    }

    public boolean reemplazarPersonaje1(String viejo, String nuevo){
        boolean reemplazar=false;
        if (party.bajoEfecto(viejo)){
            reemplazar=false;
        }else{
            reemplazar=true;
            Guerrero aux =new Guerrero(nuevo);
            party.reemplazarPersonaje(viejo, aux);
        }
        return reemplazar;
    }

    public boolean reemplazarPersonaje2(String viejo, String nuevo){
        boolean reemplazar=false;
        if (party.bajoEfecto(viejo)){
            reemplazar=false;
        }else{
            reemplazar=true;
            Asesino aux =new Asesino(nuevo);
            party.reemplazarPersonaje(viejo, aux);
        }
        return reemplazar;
    }

    public boolean reemplazarPersonaje3(String viejo, String nuevo){
        boolean reemplazar=false;
        if (party.bajoEfecto(viejo)){
            reemplazar=false;
        }else{
            reemplazar=true;
            Asesino aux =new Asesino(nuevo);
            party.reemplazarPersonaje(viejo, aux);
        }
        return reemplazar;
    }

    public boolean quitarPersonaje(String auxNom){
        boolean quitar= false;
        if(party.personajeAgotado(auxNom)){
            party.quitarPersonaje(auxNom);
            quitar=true;
        }
        return quitar;
    }
    
}
