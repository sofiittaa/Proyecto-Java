package Personaje;

public class Mentalista extends PersonajeR {
    private int foco;

    public Mentalista(String auxNom){
        this.nombre=auxNom;
        this.energia=100;
        this.foco=60;
        this.reflejo=30;
        this.clase="Mentalista";
    }
}