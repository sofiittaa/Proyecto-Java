package Personaje;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
public class VentanaListar extends JFrame{
    private Logica miLogica;
    private JPanel miPanel;
    private JLabel lblPersonajes;

    public VentanaListar(Logica auxLogica){
        this.miLogica=auxLogica;
        super("Listar Personaje");
		this.setBounds(100, 100, 500, 300);
		
		miPanel = new JPanel();
		miPanel.setBorder(new EmptyBorder(5,5,5,5));
		miPanel.setLayout(null);
		this.setContentPane(miPanel);

        lblPersonajes= new JLabel("Nombre: ");
		lblPersonajes.setBounds(50, 50, 106, 15);
		miPanel.add(lblPersonajes);
    }

}
