package Personaje;

public abstract class Personaje {
    protected String nombre;
    protected int energia;
    protected String clase;
    protected Efecto efectoActual;

    public boolean estaAgotado(){
        return this.energia <= 0;
    }

    public void aplicarEfecto(Efecto auxEfecto){
        this.efectoActual = auxEfecto;
    }

    public void quitarEfecto(){
        this.efectoActual = null;
    }

    public boolean bajoEfecto(){
        return efectoActual.estaActivo();
        }
    
    
    public Efecto getEfectoActual(){
        return this.efectoActual;
    }

    public String getNombre(){
        return this.nombre;
    }

    public String getClase(){
        return this.clase;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public int getEnergia(){
        return this.energia;
    }

    public double getDesempeno() {
        double desempeno=1;
        if(energia>50){
            desempeno=0.8;
        }
        if (efectoActual != null && this.efectoActual.estaActivo()){
            desempeno = this.efectoActual.aplicar(desempeno); 
        }
        return desempeno;
    }


}