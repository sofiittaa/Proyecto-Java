package Personaje;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
public class VentanaRegistrar extends JFrame{
    private Logica miLogica;
    private JPanel miPanel;
    private JLabel lblPedirNom;
    private JLabel lblPedirClase;
    private JTextField txtPedirNom;
    private JButton btnPersonaje1;
    private JButton btnPersonaje2;
    private JButton btnPersonaje3;

    public VentanaRegistrar(Logica auxLogica){
        this.miLogica=auxLogica;
        super("Registrar Personaje");
		this.setBounds(100, 100, 500, 300);
		
		miPanel = new JPanel();
		miPanel.setBorder(new EmptyBorder(5,5,5,5));
		miPanel.setLayout(null);
		this.setContentPane(miPanel);

        lblPedirNom= new JLabel("Nombre: ");
		lblPedirNom.setBounds(50, 50, 106, 15);
		miPanel.add(lblPedirNom);

        txtPedirNom = new JTextField();
		txtPedirNom.setBounds(100, 47, 100, 20);
		miPanel.add(txtPedirNom);


        lblPedirClase= new JLabel("Clase: ");
		lblPedirClase.setBounds(25, 120, 50, 15);
		miPanel.add(lblPedirClase);

        btnPersonaje1 = new JButton();
		btnPersonaje1.setBounds(80, 120, 100, 20);
		miPanel.add(btnPersonaje1);
		btnPersonaje1.setText("TANQUE");
		btnPersonaje1.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				regPersonaje1();
			}
		});

        btnPersonaje2 = new JButton();
		btnPersonaje2.setBounds(190, 120, 100, 20);
		miPanel.add(btnPersonaje2);
		btnPersonaje2.setText("ASESINO");
		btnPersonaje2.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				regPersonaje2();
			}
		});

        btnPersonaje3 = new JButton();
		btnPersonaje3.setBounds(300, 120, 120, 20);
		miPanel.add(btnPersonaje3);
		btnPersonaje3.setText("MENTALISTA");
		btnPersonaje3.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				regPersonaje3();
            }
		});

        
    }
    private void regPersonaje1() {
        String auxNom = txtPedirNom.getText();
		miLogica.agregarPersonaje1(auxNom);
    }
    
    private void regPersonaje2() {
        String auxNom = txtPedirNom.getText();
		miLogica.agregarPersonaje2(auxNom);
    }
    
    private void regPersonaje3() {
        String auxNom = txtPedirNom.getText();
		miLogica.agregarPersonaje3(auxNom);
    }

    

}
