package Personaje;

public class Efecto {
    private String nombre;
    private boolean positivo;
    private int duracion;

    public Efecto(String nombre, boolean positivo, int duracion) {
        this.nombre = nombre;
        this.positivo = positivo;
        this.duracion = duracion;
    }

    public boolean estaActivo(){
        return this.duracion > 0;
    }

    public double aplicar(double desempeno){
        if(this.positivo){
            desempeno=desempeno+0.2;
        }else{
            desempeno=desempeno-0.2;
        }
        return desempeno;
    }
    
    public String getNombre(){
        return this.nombre;
    }

    public boolean esPositivo(){
        return this.positivo;
    }

}